#include <Arduino.h>
#include "Behaviors.h"

Behaviors followWaypoints;

float x1 = 0; //x coordinates of each of the 5 points
float x2 = 0;
float x3 = 1;
float x4 = 1;
float x5 = 2;

float y1 = 0; //y coordinates of each of the 5 points
float y2 = 1;
float y3 = 1;
float y4 = 2;
float y5 = 2;

void setup() {
  followWaypoints.Init();
}

void loop() {
  followWaypoints.Run();

//for loop goes in followwaypoints.run

 /*
for(int i = 1; i < 6; ++i) { //loops 6 times, once for each transition to a new waypoint. The 6th loop returns to the first point
    
    Serial.print('turn and drive');
    //if at current point (set a given tolerance for being "at current point")
      //go to next point (i++)

}
*/
}